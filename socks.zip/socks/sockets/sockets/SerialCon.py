import serial
import os

port = "COM3"
users = []
COLORS = ["R","G","B","X","X","X","X","X","X"]

conn = serial.Serial(port, 9600)
conn.flushInput()

users_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'users.txt'))
config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'config.txt'))

f = open(users_path, "r")

conn.write("RST".encode())

while 1:

    if(conn.read().decode()):
        f = open(config_path, "r")
        message = f.readline()
        print(message)
        conn.write(("C:" + message).encode())
        f.close()

    f = open(users_path,"r")
    for x in f:
        if(x not in users):
            if(conn.read().decode()):
                conn.write(("N:" + x).encode())
                users.append(x)
    f.close()