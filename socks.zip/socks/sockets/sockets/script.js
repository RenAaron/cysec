// file for client side javascript 

const socket = io('http://localhost:3000') // get the socket variable as 'socket'
const messageForm = document.getElementById('send-container') // grab sender 
const messageContainer = document.getElementById('message-container')
const messageInput = document.getElementById('message-input')

const name = prompt('What is your name? ')
appendMessage("You joined")

socket.emit('new-user', name)

socket.on('chat-message', data => { // when 'socket' emits 'chat-message', take data and handle it doint the following  
    appendMessage(`${data.name}: ${data.message}`)
})

socket.on('user-connected', data => { // when 'socket' emits 'chat-message', take data and handle it doint the following  
    appendMessage(`${data.name} connected`)
    console.log(data.grid);
    updateGrid(data.grid);
})

function updateGrid(grid){
    for(let y = 1; y < 9; y++){
        for(let x = 1; x < 9; x++){
            // console.log(data.grid[[(x-1)+(y-1)*8]])
            let color = grid[[(x-1)+(y-1)*8]]
            if(color == "R"){
                // console.log("Red at " + x + ", " + y )
                setCellColor(x-1, y-1, "red")
            }  else if(color == "G"){
                setCellColor(x-1,y-1,"green")
            } else if(color == "B"){
                setCellColor(x-1,y-1,"blue")
            } else{
                setCellColor(x-1,y-1,"white")
            }
        }
    }
}

socket.on('user-disconnect', name =>{
    appendMessage(name +  " disconnected!")
})

socket.on('user-placed', grid => {
    // console.log(data.name)
    // setCellColor(data.col,data.row,data.color);
    console.log(grid);
    updateGrid(grid);

})

messageForm.addEventListener('submit', e =>{

    e.preventDefault() // prevent refreshing page 

    const message = messageInput.value // var 'message' from 'message-input' in html
    
    if(message.length > 0){
        socket.emit('send-chat-message', message) // do 'send-chat-message' passing data 'message'
        appendMessage(`You: ${message}`)
    }

    messageInput.value = '' // reset messageInput value 

    
})

document.addEventListener("DOMContentLoaded", function () {
    // Create grid
    const gridContainer = document.getElementById("gridContainer");

    for (let i = 0; i < 8; i++) {
    for (let j = 0; j < 8; j++) {
        const cell = document.createElement("div");
        cell.id = "R" + j + "C" + i
        cell.classList.add("grid-item");
        cell.addEventListener("click", function () {

            socket.emit('fill-pixel', {name: name, row: i, col: j, color : document.getElementById("colorSelector").value})

            //setCellColor(j, i, document.getElementById("colorSelector").value)
            //console.log(document.getElementById("colorSelector").value)

            // setCellColor(row, col, color)

            // this.classList.toggle(document.getElementById("colorSelector").value);

        });
        gridContainer.appendChild(cell);
    }
    }
});

function setCellColor(row, col, color){
    const cell = document.getElementById("R"+row+"C"+col)
    if(cell){

        switch(color){
            case "red":
                cell.className = "grid-red"
                break;
            case "green":
                cell.className = "grid-green"
                break;
            case "blue":
                cell.className = "grid-blue"
                break;
            case "white":
                cell.className = "grid-white"
                break;
        }
    } else{
        console.log("Cell (" + row + ", " + col + ") not found!")
    }
}

function appendMessage(message){
    const messageElement = document.createElement('div')
    messageElement.innerText = message
    messageElement.className = 'message';
    messageContainer.append(messageElement)
}