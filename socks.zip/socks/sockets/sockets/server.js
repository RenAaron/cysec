// server file for socket .io 

const users = {}
var grid = ""

const { error } = require('console')
const fs = require('fs')

fs.readFile('../../config.txt','utf8',(err, data) => {
    if(err){
        console.error(err)
        return
    }
    grid = data;
    console.log("Grid: " + grid);
})


const io = require('socket.io')(3000, {
    cors: {
        origin: "*",
    },
}) // creates a server for us on port 3000 

io.on('connection', socket => { // every time a user loads website execute following
    
    socket.on('new-user', name =>{

        if(name == "" || !name){
            console.log("Name is null!");
        } else{
            // console.log("name is not null")
            sendName(name);
        }

        fs.readFile('../../config.txt','utf8',(err, data) => {
            if(err){
                console.error(err)
                return
            }
            grid = data;
            console.log("Grid: " + grid);
        })
        
        console.log(socket.id);
        users[socket.id] = name
        socket.emit('user-connected', {name: name, grid: grid})
    })

    socket.on('send-chat-message', message => { // establish this rule 
        socket.broadcast.emit('chat-message', {message: message, name : users[socket.id] }) // send to everyone but self
    })

    socket.on('disconnect', () =>{
        socket.broadcast.emit('user-disconnect', users[socket.id])

        delete users[socket.id]
    })

    socket.on('fill-pixel', data => {
        console.log(data.name + " placed " + data.color + " at Row: " + data.row + ", Col: " + data.col)

        updateGrid()

        console.log("new Grid: " + grid)
        
        console.log("Before " + grid[(data.col+data.row*8)])

        grid = setCharAt(grid, (data.col+data.row*8), data.color[0].toUpperCase());

        fs.writeFile('../../config.txt', grid, err => {
            if(err){
                console.err;
                console.log("uh oh!")
                return
            }
        });
        socket.emit('user-placed', grid)
        socket.broadcast.emit('user-placed', grid)
    })
})

function setCharAt(str,index,chr) {
    if(index > str.length-1) return str;
    return str.substring(0,index) + chr + str.substring(index+1);
}

function updateGrid(){
    do{
        sleep(1000).then(() => {   
            console.log("Attempting....")
            fs.readFile('../../config.txt','utf8',(err, data) => {
                if(err){
                    console.error(err)
                    return
                }
                grid = data;
                if(grid == ""){
                    console.log("We have a problem")
                }
            })

        })
    }while(grid == "")
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function sendName(name){
    console.log("hehehe")
    var names = "";

    
    console.log("Attempting names....")
    fs.readFile('../../users.txt','utf8',(err, data) => {
        if(err){
            console.error(err)
            return
        }
        names = data;
        console.log("Old names: " + names);
        if(names == ""){
            console.log("We have a problem")
        }

        name = name.substring(0,8)
        name = name.concat("\n")
        names = names.concat(name)

        fs.writeFile('../../users.txt', names, err => {
            if(err){
                console.err;
                console.log("uh oh!")
                return
            }
        });
    })
}